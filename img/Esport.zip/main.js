var ss = `

    <!-- Main Content -->
    <div class="container mt-1 p-0">
      <!-- Bootstrap Carousel Slider -->
      <div id="imageSlider" class="carousel slide" data-bs-ride="carousel">
        <!-- Indicators -->
        <div class="carousel-indicators">
          <button type="button" data-bs-target="#imageSlider" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#imageSlider" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#imageSlider" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        
        <!-- Slides -->
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSW5n5OYclqxBxLRY-Rr7zpKThZuAKWMD25gTCQYiwauX3ozBnQO6x310GX&s=10" class="d-block w-100" alt="Slide 1">
          </div>
          <div class="carousel-item">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSW5n5OYclqxBxLRY-Rr7zpKThZuAKWMD25gTCQYiwauX3ozBnQO6x310GX&s=10" class="d-block w-100" alt="Slide 2">
          </div>
          <div class="carousel-item">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSW5n5OYclqxBxLRY-Rr7zpKThZuAKWMD25gTCQYiwauX3ozBnQO6x310GX&s=10" class="d-block w-100" alt="Slide 3">
          </div>
        </div>
        
        <!-- Controls -->
        <button class="carousel-control-prev" type="button" data-bs-target="#imageSlider" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#imageSlider" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
      
      <!-- Beautiful Marquee Div -->
      <div class="marquee-container mt-4">
        <div class="marquee-content">
          <span>🌟 Welcome to Our Website! 🌟</span>
          <span>🚀 Explore Amazing Features! 🚀</span>
          <span>🎉 Enjoy Exclusive Offers! 🎉</span>
          <span>❤️ Thank You for Visiting! ❤️</span>
        </div>
      </div>
    </div>
    
    <!-- Bold Title -->
    <div class="title">FreeFire</div>
    
    <!-- Two Cards in a Row -->
    <div class="container card-container">
      <div class="card">
        <img src="https://via.placeholder.com/400x200?text=Card+1+Image" alt="Card 1 Image">
        <div class="card-body">
          <h5 class="card-title">Card 1 Title</h5>
          <p class="card-text">This is a description for Card 1. It contains some details about the card's content.</p>
        </div>
      </div>
      <div class="card">
        <img src="https://via.placeholder.com/400x200?text=Card+2+Image" alt="Card 2 Image">
        <div class="card-body">
          <h5 class="card-title">Card 2 Title</h5>
          <p class="card-text">This is a description for Card 2. It contains some details about the card's content.</p>
        </div>
      </div>
    </div>
    <div class="container card-container">
      <div class="card">
        <img src="https://via.placeholder.com/400x200?text=Card+1+Image" alt="Card 1 Image">
        <div class="card-body">
          <h5 class="card-title">Card 1 Title</h5>
          <p class="card-text">This is a description for Card 1. It contains some details about the card's content.</p>
        </div>
      </div>
      <div class="card">
        <img src="https://via.placeholder.com/400x200?text=Card+2+Image" alt="Card 2 Image">
        <div class="card-body">
          <h5 class="card-title">Card 2 Title</h5>
          <p class="card-text">This is a description for Card 2. It contains some details about the card's content.</p>
        </div>
      </div>
    </div>
    <div class="container card-container">
      <div class="card">
        <img src="https://via.placeholder.com/400x200?text=Card+1+Image" alt="Card 1 Image">
        <div class="card-body">
          <h5 class="card-title">Card 1 Title</h5>
          <p class="card-text">This is a description for Card 1. It contains some details about the card's content.</p>
        </div>
      </div>
      <div class="card">
        <img src="https://via.placeholder.com/400x200?text=Card+2+Image" alt="Card 2 Image">
        <div class="card-body">
          <h5 class="card-title">Card 2 Title</h5>
          <p class="card-text">This is a description for Card 2. It contains some details about the card's content.</p>
        </div>
      </div>
    </div>
    <div style="padding: 55px 0">
      
    </div>


`




