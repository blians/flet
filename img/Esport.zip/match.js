`

    <div class="title">
      MY MATCHES
    </div>
    <div class="container mt-4">
      <div class="card" style="display: flex">
        <div class="d-flex align-items-center justify-content-between">
          <div class="m-2 ">1</div>
          <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
              <h5 class="card-title text-success font-weight-bold m-0">Friday Match | ID & Pass</h5>
              <div class="bg-dark text-white rounded px-2 py-1">TK 0</div>
            </div>
            <p class="card-title text-success font-weight-bold m-0">Give in Telegram</p>
            <div class="d-flex justify-content-between">
              <p class="card-text text-muted m-0" style="font-size: 0.8rem;">2025-03-18 02:51:00 AM</p>
              <div>#3893</div>
              
            </div>
            <p class="card-text text-dark ">Won Amount: 0 TK</p>
          </div>
          
          
        </div>
      </div>
    </div>
    
`